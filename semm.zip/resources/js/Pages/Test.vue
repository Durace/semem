<template>
  <div>
    <h1>Hello world</h1>
  </div>
</template>

<script setup>

</script>

<style lang="scss">

</style>
